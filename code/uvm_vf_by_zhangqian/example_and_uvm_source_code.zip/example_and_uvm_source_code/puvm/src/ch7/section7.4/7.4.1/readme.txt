some regs in this example is not existed in DUT, can't access correctly
