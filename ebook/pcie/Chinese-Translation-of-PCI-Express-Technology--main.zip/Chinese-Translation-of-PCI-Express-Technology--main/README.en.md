# Chinese Translation of PCI Express Technology 

#### Description
Chinese Translation on <PCI Express Technology Comprehensive Guide to Generations 1.x, 2.x and 3.0> by Mindshare


#### Copyright
Mindshare，https://www.mindshare.com/Books/Titles/
This chinses translation version can only be used for study.

#### Contribution
Michael M

