please go to 9.4.x/chip/ to run simulation
